AnySerial
=========

Arduino wrapper class for HardwareSerial, SoftwareSerial &amp; AltSoftSerial
